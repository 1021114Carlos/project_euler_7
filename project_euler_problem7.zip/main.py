""" 
The numbers 2, 3, 5, 7, 11, 13 are prime. 13 is
in index position 6.
What number is in index postion 10001
"""

primeFound = False
indexOfPrime = []
indexes = 10001
naturalNum = 1
while primeFound:
    